function DivLogin()
{
	div = document.getElementById("divLogin");
	
	if (div.style.visibility == "hidden")
	    div.style.visibility = "visible";
	else
	    div.style.visibility = "hidden";
}