<?php
echo "
<h1>P�gina Inicial</h1>
";
?>